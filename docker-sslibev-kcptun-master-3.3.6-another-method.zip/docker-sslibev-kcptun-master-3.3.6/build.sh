#!/bin/bash
docker build -t sslibev-kcptun:3.3.6 .