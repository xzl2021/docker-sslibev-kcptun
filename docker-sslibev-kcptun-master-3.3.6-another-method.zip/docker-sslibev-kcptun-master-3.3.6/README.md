# docker-sslibev-kcptun
Docker image build scripts 4 ss-libev with kcptun plugin.

## Usage
* Build:
```
sh build.sh
```
* Run:
```
sh run.sh
```